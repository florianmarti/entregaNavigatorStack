export const CART = [
  {
    id: "1",
    category: "1",
    name: "Pan Baguette",
    description: "Clasico pan frances",
    weight: "350gr",
    price: 16,
    quantity: 3,
  },
  {
    id: "2",
    category: "2",
    name: "Pan Cibatta Blanco",
    description: "Pan de alta hidratacion, miga alveolada y corteza crujiente",
    weight: "800gr",
    price: 30,
    quantity: 2,
  },
]
