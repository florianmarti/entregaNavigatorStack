export const PRODUCTS = [
  {
    id: "1",
    category: "1",
    name: "Pan Baguette",
    description: "Clasico pan frances",
    weight: "350gr",
    price: 16,
  },
  {
    id: "2",
    category: "2",
    name: "Pan Cibatta Blanco",
    description: "Pan de alta hidratacion, miga alveolada y corteza crujiente",
    weight: "800gr",
    price: 30,
  },
  {
    id: "3",
    category: "1",
    name: "Pan de hamburguesa",
    description: "Textura suave, decorado con semilla de sesamo tostadas",
    weight: "120gr",
    price: 10,
  },
  {
    id: "4",
    category: "3",
    name: "Pan de molde integral de centeno",
    description: "Pidelo entero o tajado, con o sin semillas",
    weight: "200gr",
    price: 35,
  },
  {
    id: "5",
    category: "2",
    name: "Dona de chocolate",
    description:
      "Dona cubierta de chocolate, puedes pedirlo con chocolate blanco",
    weight: "300gr",
    price: 20,
  },
]
