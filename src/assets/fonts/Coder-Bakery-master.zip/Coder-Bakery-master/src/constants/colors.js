export const COLORS = {
  priamry: "#F4AD23",
  secondary: "#EC843E",
  tertiary: "#A52556",
  quaternary: "#A44125",
}
