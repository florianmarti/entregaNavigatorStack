import { StyleSheet, Text, View } from "react-native"
import React from "react"

const OrdersScren = () => {
  return (
    <View>
      <Text>OrdersScren</Text>
    </View>
  )
}

export default OrdersScren

const styles = StyleSheet.create({})
